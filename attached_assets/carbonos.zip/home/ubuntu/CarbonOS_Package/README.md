# CarbonOS - Plateforme SaaS de Gestion Carbone

## Introduction

CarbonOS est une solution SaaS clé en main pour automatiser le calcul, le reporting et la réduction de l'empreinte carbone des PME et ETI françaises, tout en respectant le RGPD et les réglementations locales.

## Installation rapide

Pour installer CarbonOS, exécutez le script d'installation :

```bash
sudo ./install.sh
```

Ce script guidera l'installation pas à pas.

## Documentation

La documentation complète est disponible dans le répertoire `docs/` :

- `documentation_technique.md` : Architecture, stack technologique, API, etc.
- `guide_utilisateur.md` : Guide d'utilisation de l'application
- `documentation_rgpd.md` : Conformité RGPD et protection des données
- `guide_installation.md` : Guide détaillé d'installation et de déploiement

## Déploiement avec Docker

Pour déployer avec Docker, utilisez :

```bash
docker-compose -f docker-compose.prod.yml up -d
```

## Support

Pour toute question ou assistance, contactez-nous :

- Email : support@carbonos.fr
- Site web : https://carbonos.fr

## Licence

CarbonOS est distribué sous licence propriétaire. Tous droits réservés.
