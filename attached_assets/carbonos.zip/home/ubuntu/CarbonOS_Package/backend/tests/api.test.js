const { expect } = require('chai');
const request = require('supertest');
const app = require('../src/server');
const { User, Company } = require('../src/models');
const jwt = require('jsonwebtoken');
const authConfig = require('../src/config/auth');

describe('Tests d\'authentification', () => {
  let testUser;
  let testCompany;
  
  before(async () => {
    // Créer une entreprise de test
    testCompany = await Company.create({
      name: 'Entreprise Test',
      sector: 'Technologie',
      sectorCode: 'TECH',
      employeeCount: 100,
      address: '123 Rue de Test',
      postalCode: '75000',
      city: 'Paris',
      country: 'France',
      siret: '12345678901234'
    });
    
    // Créer un utilisateur de test
    testUser = await User.create({
      firstName: 'Jean',
      lastName: 'Test',
      email: 'jean.test@example.com',
      password: await bcrypt.hash('Password123!', 10),
      role: 'user',
      companyId: testCompany.id,
      consentDataProcessing: true
    });
  });
  
  after(async () => {
    // Nettoyer les données de test
    await User.destroy({ where: { id: testUser.id } });
    await Company.destroy({ where: { id: testCompany.id } });
  });
  
  describe('POST /api/auth/login', () => {
    it('devrait authentifier un utilisateur avec des identifiants valides', async () => {
      const res = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'jean.test@example.com',
          password: 'Password123!'
        });
      
      expect(res.status).to.equal(200);
      expect(res.body).to.have.property('token');
      expect(res.body).to.have.property('refreshToken');
      expect(res.body.user).to.have.property('id');
      expect(res.body.user.email).to.equal('jean.test@example.com');
    });
    
    it('devrait refuser l\'authentification avec un email invalide', async () => {
      const res = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'inexistant@example.com',
          password: 'Password123!'
        });
      
      expect(res.status).to.equal(400);
      expect(res.body).to.have.property('errors');
    });
    
    it('devrait refuser l\'authentification avec un mot de passe invalide', async () => {
      const res = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'jean.test@example.com',
          password: 'MotDePasseIncorrect'
        });
      
      expect(res.status).to.equal(400);
      expect(res.body).to.have.property('errors');
    });
  });
  
  describe('POST /api/auth/register', () => {
    it('devrait créer un nouvel utilisateur', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          firstName: 'Marie',
          lastName: 'Test',
          email: 'marie.test@example.com',
          password: 'Password123!',
          companyName: 'Nouvelle Entreprise',
          sector: 'Services',
          employeeCount: 50,
          consentDataProcessing: true
        });
      
      expect(res.status).to.equal(201);
      expect(res.body).to.have.property('token');
      expect(res.body.user).to.have.property('id');
      expect(res.body.user.email).to.equal('marie.test@example.com');
      
      // Nettoyer les données créées
      const newUser = await User.findOne({ where: { email: 'marie.test@example.com' } });
      const newCompany = await Company.findOne({ where: { name: 'Nouvelle Entreprise' } });
      
      await User.destroy({ where: { id: newUser.id } });
      await Company.destroy({ where: { id: newCompany.id } });
    });
    
    it('devrait refuser la création d\'un utilisateur avec un email existant', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          firstName: 'Jean',
          lastName: 'Duplicate',
          email: 'jean.test@example.com',
          password: 'Password123!',
          companyName: 'Entreprise Duplicate',
          sector: 'Services',
          employeeCount: 50,
          consentDataProcessing: true
        });
      
      expect(res.status).to.equal(400);
      expect(res.body).to.have.property('errors');
    });
  });
  
  describe('POST /api/auth/refresh-token', () => {
    it('devrait générer un nouveau token avec un refresh token valide', async () => {
      // D'abord se connecter pour obtenir un refresh token
      const loginRes = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'jean.test@example.com',
          password: 'Password123!'
        });
      
      const refreshToken = loginRes.body.refreshToken;
      
      const res = await request(app)
        .post('/api/auth/refresh-token')
        .send({
          refreshToken
        });
      
      expect(res.status).to.equal(200);
      expect(res.body).to.have.property('token');
      expect(res.body).to.have.property('refreshToken');
    });
    
    it('devrait refuser le rafraîchissement avec un token invalide', async () => {
      const res = await request(app)
        .post('/api/auth/refresh-token')
        .send({
          refreshToken: 'token_invalide'
        });
      
      expect(res.status).to.equal(401);
      expect(res.body).to.have.property('errors');
    });
  });
});

describe('Tests des routes utilisateurs', () => {
  let testUser;
  let testCompany;
  let authToken;
  
  before(async () => {
    // Créer une entreprise de test
    testCompany = await Company.create({
      name: 'Entreprise Test Users',
      sector: 'Technologie',
      sectorCode: 'TECH',
      employeeCount: 100,
      address: '123 Rue de Test',
      postalCode: '75000',
      city: 'Paris',
      country: 'France',
      siret: '12345678901235'
    });
    
    // Créer un utilisateur de test
    testUser = await User.create({
      firstName: 'Pierre',
      lastName: 'Test',
      email: 'pierre.test@example.com',
      password: await bcrypt.hash('Password123!', 10),
      role: 'admin',
      companyId: testCompany.id,
      consentDataProcessing: true
    });
    
    // Générer un token d'authentification
    authToken = jwt.sign(
      { user: { id: testUser.id } },
      authConfig.jwtSecret,
      { expiresIn: '1h' }
    );
  });
  
  after(async () => {
    // Nettoyer les données de test
    await User.destroy({ where: { id: testUser.id } });
    await Company.destroy({ where: { id: testCompany.id } });
  });
  
  describe('GET /api/users/me', () => {
    it('devrait récupérer les informations de l\'utilisateur connecté', async () => {
      const res = await request(app)
        .get('/api/users/me')
        .set('x-auth-token', authToken);
      
      expect(res.status).to.equal(200);
      expect(res.body).to.have.property('id');
      expect(res.body.email).to.equal('pierre.test@example.com');
    });
    
    it('devrait refuser l\'accès sans token', async () => {
      const res = await request(app)
        .get('/api/users/me');
      
      expect(res.status).to.equal(401);
      expect(res.body).to.have.property('errors');
    });
  });
  
  describe('PUT /api/users/me', () => {
    it('devrait mettre à jour les informations de l\'utilisateur', async () => {
      const res = await request(app)
        .put('/api/users/me')
        .set('x-auth-token', authToken)
        .send({
          firstName: 'Pierre Updated',
          lastName: 'Test Updated'
        });
      
      expect(res.status).to.equal(200);
      expect(res.body).to.have.property('id');
      expect(res.body.firstName).to.equal('Pierre Updated');
      expect(res.body.lastName).to.equal('Test Updated');
    });
  });
  
  describe('GET /api/users/company', () => {
    it('devrait récupérer les informations de l\'entreprise de l\'utilisateur', async () => {
      const res = await request(app)
        .get('/api/users/company')
        .set('x-auth-token', authToken);
      
      expect(res.status).to.equal(200);
      expect(res.body).to.have.property('id');
      expect(res.body.name).to.equal('Entreprise Test Users');
    });
  });
});

describe('Tests des routes d\'émissions', () => {
  let testUser;
  let testCompany;
  let authToken;
  let testEmissionData;
  
  before(async () => {
    // Créer une entreprise de test
    testCompany = await Company.create({
      name: 'Entreprise Test Emissions',
      sector: 'Technologie',
      sectorCode: 'TECH',
      employeeCount: 100,
      address: '123 Rue de Test',
      postalCode: '75000',
      city: 'Paris',
      country: 'France',
      siret: '12345678901236'
    });
    
    // Créer un utilisateur de test
    testUser = await User.create({
      firstName: 'Sophie',
      lastName: 'Test',
      email: 'sophie.test@example.com',
      password: await bcrypt.hash('Password123!', 10),
      role: 'editor',
      companyId: testCompany.id,
      consentDataProcessing: true
    });
    
    // Générer un token d'authentification
    authToken = jwt.sign(
      { user: { id: testUser.id } },
      authConfig.jwtSecret,
      { expiresIn: '1h' }
    );
    
    // Créer des données d'émission de test
    testEmissionData = await EmissionData.create({
      reportingPeriod: '2024-01-01 to 2024-12-31',
      reportingYear: 2024,
      companyId: testCompany.id,
      submittedBy: testUser.id,
      submittedAt: new Date(),
      status: 'draft',
      scope1Total: 100,
      scope2Total: 200,
      scope3Total: 300,
      totalEmissions: 600
    });
  });
  
  after(async () => {
    // Nettoyer les données de test
    await EmissionData.destroy({ where: { id: testEmissionData.id } });
    await User.destroy({ where: { id: testUser.id } });
    await Company.destroy({ where: { id: testCompany.id } });
  });
  
  describe('GET /api/emissions', () => {
    it('devrait récupérer les données d\'émissions de l\'entreprise', async () => {
      const res = await request(app)
        .get('/api/emissions')
        .set('x-auth-token', authToken);
      
      expect(res.status).to.equal(200);
      expect(res.body).to.be.an('array');
      expect(res.body.length).to.be.at.least(1);
      expect(res.body[0]).to.have.property('id');
      expect(res.body[0].companyId).to.equal(testCompany.id);
    });
  });
  
  describe('GET /api/emissions/:id', () => {
    it('devrait récupérer une donnée d\'émission spécifique', async () => {
      const res = await request(app)
        .get(`/api/emissions/${testEmissionData.id}`)
        .set('x-auth-token', authToken);
      
      expect(res.status).to.equal(200);
      expect(res.body).to.have.property('id');
      expect(res.body.id).to.equal(testEmissionData.id);
      expect(res.body.reportingYear).to.equal(2024);
    });
    
    it('devrait retourner une erreur pour un ID inexistant', async () => {
      const res = await request(app)
        .get('/api/emissions/999999')
        .set('x-auth-token', authToken);
      
      expect(res.status).to.equal(404);
      expect(res.body).to.have.property('errors');
    });
  });
  
  describe('POST /api/emissions', () => {
    it('devrait créer une nouvelle donnée d\'émission', async () => {
      const res = await request(app)
        .post('/api/emissions')
        .set('x-auth-token', authToken)
        .send({
          reportingPeriod: '2023-01-01 to 2023-12-31',
          reportingYear: 2023,
          companyId: testCompany.id,
          methodologyNotes: 'Test methodology'
        });
      
      expect(res.status).to.equal(200);
      expect(res.body).to.have.property('id');
      expect(res.body.reportingYear).to.equal(2023);
      
      // Nettoyer la donnée créée
      await EmissionData.destroy({ where: { id: res.body.id } });
    });
  });
  
  describe('PUT /api/emissions/:id', () => {
    it('devrait mettre à jour une donnée d\'émission', async () => {
      const res = await request(app)
        .put(`/api/emissions/${testEmissionData.id}`)
        .set('x-auth-token', authToken)
        .send({
          reportingPeriod: '2024-01-01 to 2024-12-31',
          reportingYear: 2024,
          methodologyNotes: 'Updated methodology',
          status: 'submitted'
        });
      
      expect(res.status).to.equal(200);
      expect(res.body).to.have.property('id');
      expect(res.body.id).to.equal(testEmissionData.id);
      expect(res.body.methodologyNotes).to.equal('Updated methodology');
      expect(res.body.status).to.equal('submitted');
    });
  });
});

describe('Tests des routes RGPD', () => {
  let testUser;
  let testCompany;
  let authToken;
  
  before(async () => {
    // Créer une entreprise de test
    testCompany = await Company.create({
      name: 'Entreprise Test RGPD',
      sector: 'Technologie',
      sectorCode: 'TECH',
      employeeCount: 100,
      address: '123 Rue de Test',
      postalCode: '75000',
      city: 'Paris',
      country: 'France',
      siret: '12345678901237'
    });
    
    // Créer un utilisateur de test
    testUser = await User.create({
      firstName: 'Lucas',
      lastName: 'Test',
      email: 'lucas.test@example.com',
      password: await bcrypt.hash('Password123!', 10),
      role: 'user',
      companyId: testCompany.id,
      consentDataProcessing: true
    });
    
    // Générer un token d'authentification
    authToken = jwt.sign(
      { user: { id: testUser.id } },
      authConfig.jwtSecret,
      { expiresIn: '1h' }
    );
  });
  
  after(async () => {
    // Nettoyer les données de test
    await User.destroy({ where: { id: testUser.id } });
    await Company.destroy({ where: { id: testCompany.id } });
  });
  
  describe('GET /api/rgpd/consents', () => {
    it('devrait récupérer les consentements de l\'utilisateur', async () => {
      const res = await request(app)
        .get('/api/rgpd/consents')
        .set('x-auth-token', authToken);
      
      expect(res.status).to.equal(200);
      expect(res.body).to.be.an('array');
    });
  });
  
  describe('POST /api/rgpd/consents', () => {
    it('devrait créer un nouveau consentement', async () => {
      const res = await request(app)
        .post('/api/rgpd/consents')
        .set('x-auth-token', authToken)
        .send({
          type: 'marketing',
          status: true,
          version: '1.0'
        });
      
      expect(res.status).to.equal(200);
      expect(res.body).to.have.property('id');
      expect(res.body.type).to.equal('marketing');
      expect(res.body.status).to.equal(true);
    });
  });
  
  describe('GET /api/rgpd/export-data', () => {
    it('devrait exporter les données personnelles de l\'utilisateur', async () => {
      const res = await request(app)
        .get('/api/rgpd/export-data')
        .set('x-auth-token', authToken);
      
      expect(res.status).to.equal(200);
      expect(res.body).to.have.property('user');
      expect(res.body.user.id).to.equal(testUser.id);
      expect(res.body.user.email).to.equal('lucas.test@example.com');
    });
  });
  
  describe('GET /api/rgpd/policies/privacy', () => {
    it('devrait récupérer la politique de confidentialité', async () => {
      const res = await request(app)
        .get('/api/rgpd/policies/privacy');
      
      expect(res.status).to.equal(200);
      expect(res.body).to.have.property('title');
      expect(res.body.title).to.equal('Politique de Confidentialité');
    });
  });
});
