const { expect } = require('chai');
const request = require('supertest');
const app = require('../src/server');
const { User, Company } = require('../src/models');
const jwt = require('jsonwebtoken');
const authConfig = require('../src/config/auth');
const autocannon = require('autocannon');
const { promisify } = require('util');

// Convertir autocannon en promesse
const autocannonAsync = promisify((opts, cb) => {
  autocannon(opts, (err, result) => {
    cb(err, result);
  });
});

describe('Tests de performance', () => {
  let testUser;
  let testCompany;
  let authToken;
  
  before(async () => {
    // Créer une entreprise de test
    testCompany = await Company.create({
      name: 'Entreprise Test Performance',
      sector: 'Technologie',
      sectorCode: 'TECH',
      employeeCount: 100,
      address: '123 Rue de Test',
      postalCode: '75000',
      city: 'Paris',
      country: 'France',
      siret: '12345678901239'
    });
    
    // Créer un utilisateur de test
    testUser = await User.create({
      firstName: 'Thomas',
      lastName: 'Test',
      email: 'thomas.test@example.com',
      password: await bcrypt.hash('Password123!', 10),
      role: 'user',
      companyId: testCompany.id,
      consentDataProcessing: true
    });
    
    // Générer un token d'authentification
    authToken = jwt.sign(
      { user: { id: testUser.id } },
      authConfig.jwtSecret,
      { expiresIn: '1h' }
    );
  });
  
  after(async () => {
    // Nettoyer les données de test
    await User.destroy({ where: { id: testUser.id } });
    await Company.destroy({ where: { id: testCompany.id } });
  });
  
  it('devrait supporter une charge de 100 requêtes simultanées sur la page d\'accueil', async () => {
    const result = await autocannonAsync({
      url: 'http://localhost:5000',
      connections: 100,
      duration: 10,
      title: 'Test de charge - Page d\'accueil'
    });
    
    console.log('Résultats du test de charge - Page d\'accueil:');
    console.log(`Requêtes par seconde: ${result.requests.average}`);
    console.log(`Latence moyenne: ${result.latency.average} ms`);
    console.log(`Taux d'erreur: ${result.errors / result.requests.total * 100}%`);
    
    expect(result.errors).to.equal(0);
    expect(result.requests.average).to.be.at.least(500);
    expect(result.latency.average).to.be.below(100);
  });
  
  it('devrait supporter une charge de 50 requêtes simultanées sur l\'API d\'authentification', async () => {
    const result = await autocannonAsync({
      url: 'http://localhost:5000/api/auth/login',
      connections: 50,
      duration: 10,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        email: 'thomas.test@example.com',
        password: 'Password123!'
      }),
      title: 'Test de charge - API d\'authentification'
    });
    
    console.log('Résultats du test de charge - API d\'authentification:');
    console.log(`Requêtes par seconde: ${result.requests.average}`);
    console.log(`Latence moyenne: ${result.latency.average} ms`);
    console.log(`Taux d'erreur: ${result.errors / result.requests.total * 100}%`);
    
    expect(result.errors).to.equal(0);
    expect(result.requests.average).to.be.at.least(200);
    expect(result.latency.average).to.be.below(200);
  });
  
  it('devrait supporter une charge de 30 requêtes simultanées sur l\'API des émissions', async () => {
    const result = await autocannonAsync({
      url: 'http://localhost:5000/api/emissions',
      connections: 30,
      duration: 10,
      headers: {
        'x-auth-token': authToken
      },
      title: 'Test de charge - API des émissions'
    });
    
    console.log('Résultats du test de charge - API des émissions:');
    console.log(`Requêtes par seconde: ${result.requests.average}`);
    console.log(`Latence moyenne: ${result.latency.average} ms`);
    console.log(`Taux d'erreur: ${result.errors / result.requests.total * 100}%`);
    
    expect(result.errors).to.equal(0);
    expect(result.requests.average).to.be.at.least(150);
    expect(result.latency.average).to.be.below(300);
  });
  
  it('devrait supporter une charge de 20 requêtes simultanées sur l\'API du tableau de bord', async () => {
    const result = await autocannonAsync({
      url: 'http://localhost:5000/api/dashboard',
      connections: 20,
      duration: 10,
      headers: {
        'x-auth-token': authToken
      },
      title: 'Test de charge - API du tableau de bord'
    });
    
    console.log('Résultats du test de charge - API du tableau de bord:');
    console.log(`Requêtes par seconde: ${result.requests.average}`);
    console.log(`Latence moyenne: ${result.latency.average} ms`);
    console.log(`Taux d'erreur: ${result.errors / result.requests.total * 100}%`);
    
    expect(result.errors).to.equal(0);
    expect(result.requests.average).to.be.at.least(100);
    expect(result.latency.average).to.be.below(500);
  });
  
  it('devrait supporter une charge de 10 requêtes simultanées sur l\'API RGPD', async () => {
    const result = await autocannonAsync({
      url: 'http://localhost:5000/api/rgpd/export-data',
      connections: 10,
      duration: 10,
      headers: {
        'x-auth-token': authToken
      },
      title: 'Test de charge - API RGPD'
    });
    
    console.log('Résultats du test de charge - API RGPD:');
    console.log(`Requêtes par seconde: ${result.requests.average}`);
    console.log(`Latence moyenne: ${result.latency.average} ms`);
    console.log(`Taux d'erreur: ${result.errors / result.requests.total * 100}%`);
    
    expect(result.errors).to.equal(0);
    expect(result.requests.average).to.be.at.least(50);
    expect(result.latency.average).to.be.below(1000);
  });
});
