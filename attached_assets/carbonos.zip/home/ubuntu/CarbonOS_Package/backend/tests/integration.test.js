const { expect } = require('chai');
const request = require('supertest');
const app = require('../src/server');
const { User, Company, EmissionData, Report } = require('../src/models');
const jwt = require('jsonwebtoken');
const authConfig = require('../src/config/auth');

describe('Tests d\'intégration', () => {
  let testUser;
  let testCompany;
  let authToken;
  let testEmissionData;
  
  before(async () => {
    // Créer une entreprise de test
    testCompany = await Company.create({
      name: 'Entreprise Test Intégration',
      sector: 'Technologie',
      sectorCode: 'TECH',
      employeeCount: 100,
      address: '123 Rue de Test',
      postalCode: '75000',
      city: 'Paris',
      country: 'France',
      siret: '12345678901238'
    });
    
    // Créer un utilisateur de test
    testUser = await User.create({
      firstName: 'Emma',
      lastName: 'Test',
      email: 'emma.test@example.com',
      password: await bcrypt.hash('Password123!', 10),
      role: 'editor',
      companyId: testCompany.id,
      consentDataProcessing: true
    });
    
    // Générer un token d'authentification
    authToken = jwt.sign(
      { user: { id: testUser.id } },
      authConfig.jwtSecret,
      { expiresIn: '1h' }
    );
    
    // Créer des données d'émission de test
    testEmissionData = await EmissionData.create({
      reportingPeriod: '2024-01-01 to 2024-12-31',
      reportingYear: 2024,
      companyId: testCompany.id,
      submittedBy: testUser.id,
      submittedAt: new Date(),
      status: 'validated',
      scope1Total: 100,
      scope2Total: 200,
      scope3Total: 300,
      totalEmissions: 600
    });
  });
  
  after(async () => {
    // Nettoyer les données de test
    await EmissionData.destroy({ where: { id: testEmissionData.id } });
    await User.destroy({ where: { id: testUser.id } });
    await Company.destroy({ where: { id: testCompany.id } });
  });
  
  describe('Flux de travail complet', () => {
    it('devrait permettre de créer un rapport à partir des données d\'émission', async () => {
      // 1. Créer un rapport
      const createReportRes = await request(app)
        .post('/api/reports')
        .set('x-auth-token', authToken)
        .send({
          title: 'Rapport de test',
          type: 'beges',
          period: '2024',
          format: 'pdf',
          emissionDataId: testEmissionData.id,
          isPublic: false
        });
      
      expect(createReportRes.status).to.equal(200);
      expect(createReportRes.body).to.have.property('id');
      
      const reportId = createReportRes.body.id;
      
      // 2. Vérifier que le rapport a été créé
      const getReportRes = await request(app)
        .get(`/api/reports/${reportId}`)
        .set('x-auth-token', authToken);
      
      expect(getReportRes.status).to.equal(200);
      expect(getReportRes.body).to.have.property('id');
      expect(getReportRes.body.id).to.equal(reportId);
      
      // 3. Partager le rapport avec un autre utilisateur
      // D'abord créer un autre utilisateur
      const otherUser = await User.create({
        firstName: 'Alex',
        lastName: 'Test',
        email: 'alex.test@example.com',
        password: await bcrypt.hash('Password123!', 10),
        role: 'user',
        companyId: testCompany.id,
        consentDataProcessing: true
      });
      
      const shareReportRes = await request(app)
        .post(`/api/reports/${reportId}/share`)
        .set('x-auth-token', authToken)
        .send({
          sharedWith: otherUser.id,
          accessLevel: 'view'
        });
      
      expect(shareReportRes.status).to.equal(200);
      expect(shareReportRes.body).to.have.property('id');
      
      // 4. Vérifier que l'autre utilisateur peut accéder au rapport
      const otherUserToken = jwt.sign(
        { user: { id: otherUser.id } },
        authConfig.jwtSecret,
        { expiresIn: '1h' }
      );
      
      const getSharedReportRes = await request(app)
        .get(`/api/reports/${reportId}`)
        .set('x-auth-token', otherUserToken);
      
      expect(getSharedReportRes.status).to.equal(200);
      expect(getSharedReportRes.body).to.have.property('id');
      expect(getSharedReportRes.body.id).to.equal(reportId);
      
      // Nettoyer les données créées
      await User.destroy({ where: { id: otherUser.id } });
      await Report.destroy({ where: { id: reportId } });
    });
    
    it('devrait permettre de gérer les consentements RGPD', async () => {
      // 1. Vérifier les consentements actuels
      const getConsentsRes = await request(app)
        .get('/api/rgpd/consents')
        .set('x-auth-token', authToken);
      
      expect(getConsentsRes.status).to.equal(200);
      expect(getConsentsRes.body).to.be.an('array');
      
      // 2. Ajouter un nouveau consentement
      const addConsentRes = await request(app)
        .post('/api/rgpd/consents')
        .set('x-auth-token', authToken)
        .send({
          type: 'marketing',
          status: true,
          version: '1.0'
        });
      
      expect(addConsentRes.status).to.equal(200);
      expect(addConsentRes.body).to.have.property('id');
      expect(addConsentRes.body.type).to.equal('marketing');
      expect(addConsentRes.body.status).to.equal(true);
      
      // 3. Vérifier que le consentement a été ajouté
      const getUpdatedConsentsRes = await request(app)
        .get('/api/rgpd/consents')
        .set('x-auth-token', authToken);
      
      expect(getUpdatedConsentsRes.status).to.equal(200);
      expect(getUpdatedConsentsRes.body).to.be.an('array');
      
      const marketingConsent = getUpdatedConsentsRes.body.find(c => c.type === 'marketing');
      expect(marketingConsent).to.exist;
      expect(marketingConsent.status).to.equal(true);
      
      // 4. Révoquer le consentement
      const revokeConsentRes = await request(app)
        .post('/api/rgpd/consents')
        .set('x-auth-token', authToken)
        .send({
          type: 'marketing',
          status: false,
          version: '1.0'
        });
      
      expect(revokeConsentRes.status).to.equal(200);
      expect(revokeConsentRes.body).to.have.property('id');
      expect(revokeConsentRes.body.type).to.equal('marketing');
      expect(revokeConsentRes.body.status).to.equal(false);
    });
    
    it('devrait permettre d\'exporter les données personnelles', async () => {
      const exportDataRes = await request(app)
        .get('/api/rgpd/export-data')
        .set('x-auth-token', authToken);
      
      expect(exportDataRes.status).to.equal(200);
      expect(exportDataRes.body).to.have.property('user');
      expect(exportDataRes.body.user.id).to.equal(testUser.id);
      expect(exportDataRes.body.user.email).to.equal('emma.test@example.com');
    });
  });
  
  describe('Tests de sécurité', () => {
    it('devrait refuser l\'accès sans authentification', async () => {
      const res = await request(app)
        .get('/api/users/me');
      
      expect(res.status).to.equal(401);
      expect(res.body).to.have.property('errors');
    });
    
    it('devrait refuser l\'accès avec un token invalide', async () => {
      const res = await request(app)
        .get('/api/users/me')
        .set('x-auth-token', 'invalid_token');
      
      expect(res.status).to.equal(401);
      expect(res.body).to.have.property('errors');
    });
    
    it('devrait refuser l\'accès aux ressources d\'une autre entreprise', async () => {
      // Créer une autre entreprise et un autre utilisateur
      const otherCompany = await Company.create({
        name: 'Autre Entreprise',
        sector: 'Services',
        sectorCode: 'SERV',
        employeeCount: 50,
        address: '456 Rue Autre',
        postalCode: '69000',
        city: 'Lyon',
        country: 'France',
        siret: '98765432109876'
      });
      
      const otherUser = await User.create({
        firstName: 'Paul',
        lastName: 'Autre',
        email: 'paul.autre@example.com',
        password: await bcrypt.hash('Password123!', 10),
        role: 'user',
        companyId: otherCompany.id,
        consentDataProcessing: true
      });
      
      // Créer des données d'émission pour l'autre entreprise
      const otherEmissionData = await EmissionData.create({
        reportingPeriod: '2024-01-01 to 2024-12-31',
        reportingYear: 2024,
        companyId: otherCompany.id,
        submittedBy: otherUser.id,
        submittedAt: new Date(),
        status: 'validated',
        scope1Total: 150,
        scope2Total: 250,
        scope3Total: 350,
        totalEmissions: 750
      });
      
      // Générer un token pour l'autre utilisateur
      const otherUserToken = jwt.sign(
        { user: { id: otherUser.id } },
        authConfig.jwtSecret,
        { expiresIn: '1h' }
      );
      
      // Essayer d'accéder aux données d'émission de la première entreprise
      const res = await request(app)
        .get(`/api/emissions/${testEmissionData.id}`)
        .set('x-auth-token', otherUserToken);
      
      expect(res.status).to.equal(404);
      expect(res.body).to.have.property('errors');
      
      // Nettoyer les données créées
      await EmissionData.destroy({ where: { id: otherEmissionData.id } });
      await User.destroy({ where: { id: otherUser.id } });
      await Company.destroy({ where: { id: otherCompany.id } });
    });
    
    it('devrait vérifier le consentement au traitement des données', async () => {
      // Créer un utilisateur sans consentement
      const noConsentUser = await User.create({
        firstName: 'Marie',
        lastName: 'NoConsent',
        email: 'marie.noconsent@example.com',
        password: await bcrypt.hash('Password123!', 10),
        role: 'user',
        companyId: testCompany.id,
        consentDataProcessing: false
      });
      
      // Générer un token pour cet utilisateur
      const noConsentToken = jwt.sign(
        { user: { id: noConsentUser.id } },
        authConfig.jwtSecret,
        { expiresIn: '1h' }
      );
      
      // Essayer d'accéder à une route protégée par le middleware de consentement
      const res = await request(app)
        .get('/api/rgpd/export-data')
        .set('x-auth-token', noConsentToken);
      
      expect(res.status).to.equal(403);
      expect(res.body).to.have.property('errors');
      expect(res.body.errors[0]).to.have.property('code', 'CONSENT_REQUIRED');
      
      // Nettoyer les données créées
      await User.destroy({ where: { id: noConsentUser.id } });
    });
  });
});
