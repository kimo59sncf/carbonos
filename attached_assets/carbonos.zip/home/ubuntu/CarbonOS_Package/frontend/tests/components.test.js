import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import Login from '../src/pages/Login';
import Dashboard from '../src/pages/Dashboard';
import EmissionsCalculator from '../src/pages/EmissionsCalculator';
import Reports from '../src/pages/Reports';

const middlewares = [thunk];
const mockStore = configureStore(middlewares);

describe('Tests des composants Frontend', () => {
  describe('Composant Login', () => {
    let store;
    
    beforeEach(() => {
      store = mockStore({
        auth: {
          isAuthenticated: false,
          loading: false,
          error: null
        }
      });
      
      store.dispatch = jest.fn();
    });
    
    test('Affiche le formulaire de connexion', () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <Login />
          </BrowserRouter>
        </Provider>
      );
      
      expect(screen.getByText(/Connexion/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/Email/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/Mot de passe/i)).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /Se connecter/i })).toBeInTheDocument();
    });
    
    test('Soumet le formulaire avec les données correctes', async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <Login />
          </BrowserRouter>
        </Provider>
      );
      
      fireEvent.change(screen.getByLabelText(/Email/i), {
        target: { value: 'test@example.com' }
      });
      
      fireEvent.change(screen.getByLabelText(/Mot de passe/i), {
        target: { value: 'password123' }
      });
      
      fireEvent.click(screen.getByRole('button', { name: /Se connecter/i }));
      
      await waitFor(() => {
        expect(store.dispatch).toHaveBeenCalledWith(
          expect.objectContaining({
            type: 'LOGIN_REQUEST'
          })
        );
      });
    });
    
    test('Affiche une erreur pour un formulaire incomplet', async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <Login />
          </BrowserRouter>
        </Provider>
      );
      
      fireEvent.click(screen.getByRole('button', { name: /Se connecter/i }));
      
      await waitFor(() => {
        expect(screen.getByText(/Veuillez remplir tous les champs/i)).toBeInTheDocument();
      });
    });
  });
  
  describe('Composant Dashboard', () => {
    let store;
    
    beforeEach(() => {
      store = mockStore({
        auth: {
          isAuthenticated: true,
          user: {
            id: 1,
            firstName: 'Jean',
            lastName: 'Test',
            email: 'jean.test@example.com',
            role: 'user',
            company: {
              id: 1,
              name: 'Entreprise Test',
              sector: 'Technologie'
            }
          }
        },
        dashboard: {
          loading: false,
          data: {
            companyInfo: {
              id: 1,
              name: 'Entreprise Test',
              sector: 'Technologie',
              employeeCount: 100
            },
            latestEmissions: [
              {
                id: 1,
                reportingYear: 2024,
                scope1Total: 100,
                scope2Total: 200,
                scope3Total: 300,
                totalEmissions: 600,
                status: 'validated'
              }
            ],
            emissionTrends: [
              {
                reportingYear: 2022,
                scope1Total: 120,
                scope2Total: 220,
                scope3Total: 320,
                totalEmissions: 660
              },
              {
                reportingYear: 2023,
                scope1Total: 110,
                scope2Total: 210,
                scope3Total: 310,
                totalEmissions: 630
              },
              {
                reportingYear: 2024,
                scope1Total: 100,
                scope2Total: 200,
                scope3Total: 300,
                totalEmissions: 600
              }
            ],
            alerts: [
              {
                id: 1,
                title: 'Échéance BEGES',
                description: 'Le Bilan d\'Émissions de Gaz à Effet de Serre (BEGES) pour l\'année 2024 doit être soumis avant le 31 décembre 2024.',
                dueDate: '2024-12-31',
                type: 'regulatory',
                severity: 'high'
              }
            ],
            summaryStats: {
              totalReports: 5,
              completedEmissionsData: 3,
              pendingValidations: 1
            }
          }
        }
      });
      
      store.dispatch = jest.fn();
    });
    
    test('Affiche le tableau de bord avec les données', () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <Dashboard />
          </BrowserRouter>
        </Provider>
      );
      
      expect(screen.getByText(/Tableau de bord/i)).toBeInTheDocument();
      expect(screen.getByText(/Entreprise Test/i)).toBeInTheDocument();
      expect(screen.getByText(/600/i)).toBeInTheDocument(); // Total des émissions
      expect(screen.getByText(/Échéance BEGES/i)).toBeInTheDocument();
    });
    
    test('Affiche les graphiques d\'émissions', () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <Dashboard />
          </BrowserRouter>
        </Provider>
      );
      
      expect(screen.getByText(/Émissions par scope/i)).toBeInTheDocument();
      expect(screen.getByText(/Tendance des émissions/i)).toBeInTheDocument();
    });
  });
  
  describe('Composant EmissionsCalculator', () => {
    let store;
    
    beforeEach(() => {
      store = mockStore({
        auth: {
          isAuthenticated: true,
          user: {
            id: 1,
            firstName: 'Jean',
            lastName: 'Test',
            email: 'jean.test@example.com',
            role: 'user',
            company: {
              id: 1,
              name: 'Entreprise Test',
              sector: 'Technologie'
            }
          }
        },
        emissions: {
          loading: false,
          currentEmission: null,
          emissionsList: [],
          error: null
        }
      });
      
      store.dispatch = jest.fn();
    });
    
    test('Affiche le formulaire de calcul d\'émissions', () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <EmissionsCalculator />
          </BrowserRouter>
        </Provider>
      );
      
      expect(screen.getByText(/Calculateur d'émissions/i)).toBeInTheDocument();
      expect(screen.getByText(/Scope 1/i)).toBeInTheDocument();
      expect(screen.getByText(/Scope 2/i)).toBeInTheDocument();
      expect(screen.getByText(/Scope 3/i)).toBeInTheDocument();
    });
    
    test('Permet d\'ajouter une source d\'émission', async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <EmissionsCalculator />
          </BrowserRouter>
        </Provider>
      );
      
      fireEvent.click(screen.getByText(/Ajouter une source/i));
      
      await waitFor(() => {
        expect(screen.getByText(/Détails de la source/i)).toBeInTheDocument();
      });
    });
  });
  
  describe('Composant Reports', () => {
    let store;
    
    beforeEach(() => {
      store = mockStore({
        auth: {
          isAuthenticated: true,
          user: {
            id: 1,
            firstName: 'Jean',
            lastName: 'Test',
            email: 'jean.test@example.com',
            role: 'user',
            company: {
              id: 1,
              name: 'Entreprise Test',
              sector: 'Technologie'
            }
          }
        },
        reports: {
          loading: false,
          reportsList: [
            {
              id: 1,
              title: 'BEGES 2024',
              type: 'beges',
              period: '2024',
              format: 'pdf',
              status: 'completed',
              createdAt: '2024-03-15T10:00:00Z'
            },
            {
              id: 2,
              title: 'CSRD 2024',
              type: 'csrd',
              period: '2024',
              format: 'xbrl',
              status: 'pending',
              createdAt: '2024-03-20T14:30:00Z'
            }
          ],
          error: null
        }
      });
      
      store.dispatch = jest.fn();
    });
    
    test('Affiche la liste des rapports', () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <Reports />
          </BrowserRouter>
        </Provider>
      );
      
      expect(screen.getByText(/Rapports/i)).toBeInTheDocument();
      expect(screen.getByText(/BEGES 2024/i)).toBeInTheDocument();
      expect(screen.getByText(/CSRD 2024/i)).toBeInTheDocument();
    });
    
    test('Permet de générer un nouveau rapport', async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <Reports />
          </BrowserRouter>
        </Provider>
      );
      
      fireEvent.click(screen.getByText(/Générer un rapport/i));
      
      await waitFor(() => {
        expect(screen.getByText(/Nouveau rapport/i)).toBeInTheDocument();
      });
    });
  });
});
